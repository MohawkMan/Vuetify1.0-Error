Litmus Builder
==============

The contents of this .zip file were downloaded from Litmus Builder at www.litmus.com.

Please note if your images are linked as relative paths in your HTML files (e.g. <img src="example.jpg">) you may need to upload the images to a server and change your links to an absolute URL path (e.g. <img src="http://litmus.com/example.jpg">) in order to send directly from your ESP.

If you have any questions please visit www.litmus.com/help or email hello@litmus.com.

Happy Testing!

The Litmus Team
